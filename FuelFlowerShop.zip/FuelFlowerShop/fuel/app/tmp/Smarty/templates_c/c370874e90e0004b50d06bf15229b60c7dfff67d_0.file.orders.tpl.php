<?php
/* Smarty version 3.1.29, created on 2016-04-27 01:48:29
  from "/Users/christopherschellberg/NetBeansProjects/FuelFlowerShop/fuel/app/views/member/orders.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_571ffe4d948f59_47997194',
  'file_dependency' => 
  array (
    'c370874e90e0004b50d06bf15229b60c7dfff67d' => 
    array (
      0 => '/Users/christopherschellberg/NetBeansProjects/FuelFlowerShop/fuel/app/views/member/orders.tpl',
      1 => 1461714506,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:layout.tpl' => 1,
  ),
),false)) {
function content_571ffe4d948f59_47997194 ($_smarty_tpl) {
$_smarty_tpl->ext->_inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->ext->_inheritance->processBlock($_smarty_tpl, 0, "localstyle", array (
  0 => 'block_474582877571ffe4d9179e2_72100527',
  1 => false,
  3 => 0,
  2 => 0,
));
?>


<?php 
$_smarty_tpl->ext->_inheritance->processBlock($_smarty_tpl, 0, "content", array (
  0 => 'block_1055669133571ffe4d91e683_13286962',
  1 => false,
  3 => 0,
  2 => 0,
));
$_smarty_tpl->ext->_inheritance->endChild($_smarty_tpl);
$_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:layout.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 2, false);
}
/* {block 'localstyle'}  file:/Users/christopherschellberg/NetBeansProjects/FuelFlowerShop/fuel/app/views/member/orders.tpl */
function block_474582877571ffe4d9179e2_72100527($_smarty_tpl, $_blockParentStack) {
?>

  <?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['asset_css'][0][0]->asset_css(array('refs'=>"table-display.css"),$_smarty_tpl);?>

  <style type='text/css'>
  </style>
<?php
}
/* {/block 'localstyle'} */
/* {block 'content'}  file:/Users/christopherschellberg/NetBeansProjects/FuelFlowerShop/fuel/app/views/member/orders.tpl */
function block_1055669133571ffe4d91e683_13286962($_smarty_tpl, $_blockParentStack) {
?>


  <h2><?php echo $_smarty_tpl->tpl_vars['page_title']->value;?>
</h2>
<h4 class="message"><?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['session_get_flash'][0][0]->session_get_flash(array('var'=>'message'),$_smarty_tpl);?>
</h4>
<?php if ($_smarty_tpl->tpl_vars['message']->value == 'There are no orders') {?>
    <tr><?php echo $_smarty_tpl->tpl_vars['message']->value;?>
</tr>
<?php } else { ?>
<table class='orders' frame='hsides'>
    <?php
$_from = $_smarty_tpl->tpl_vars['orders_data']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$__foreach_basket_id_0_saved_item = isset($_smarty_tpl->tpl_vars['basket_id']) ? $_smarty_tpl->tpl_vars['basket_id'] : false;
$_smarty_tpl->tpl_vars['basket_id'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['basket_id']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['basket_id']->value) {
$_smarty_tpl->tpl_vars['basket_id']->_loop = true;
$__foreach_basket_id_0_saved_local_item = $_smarty_tpl->tpl_vars['basket_id'];
?>
        <tr>
            <td>
                <a href="<?php echo $_smarty_tpl->tpl_vars['orderDetailsUrl']->value;?>
/<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['basket_id']->value['id'], ENT_QUOTES, 'UTF-8', true);?>
">Order #<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['basket_id']->value['id'], ENT_QUOTES, 'UTF-8', true);?>
</a>
            </td>
            <td>Time: <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['basket_id']->value['made_on'], ENT_QUOTES, 'UTF-8', true);?>
</td>
            <?php if ($_smarty_tpl->tpl_vars['session']->value->get('member') && $_smarty_tpl->tpl_vars['session']->value->get('member')->is_admin) {?>
            <td>Made by: <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['basket_id']->value['member_name'], ENT_QUOTES, 'UTF-8', true);?>
</td>
            <?php }?>
        </tr>
    <?php
$_smarty_tpl->tpl_vars['basket_id'] = $__foreach_basket_id_0_saved_local_item;
}
if ($__foreach_basket_id_0_saved_item) {
$_smarty_tpl->tpl_vars['basket_id'] = $__foreach_basket_id_0_saved_item;
}
?>
</table>
<?php }
}
/* {/block 'content'} */
}

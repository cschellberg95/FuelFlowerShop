<?php
/* Smarty version 3.1.29, created on 2016-04-19 03:04:17
  from "/Users/christopherschellberg/NetBeansProjects/FuelFlowerShop/fuel/app/views/member/createAccount.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57158411963131_06013997',
  'file_dependency' => 
  array (
    '1fd196af88b3b18b27e3156da1238a8e5eec7bcf' => 
    array (
      0 => '/Users/christopherschellberg/NetBeansProjects/FuelFlowerShop/fuel/app/views/member/createAccount.tpl',
      1 => 1461027849,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:layout.tpl' => 1,
  ),
),false)) {
function content_57158411963131_06013997 ($_smarty_tpl) {
$_smarty_tpl->ext->_inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->ext->_inheritance->processBlock($_smarty_tpl, 0, 'localstyle', array (
  0 => 'block_1986847628571584118eba55_98791135',
  1 => false,
  3 => 0,
  2 => 0,
));
?>


<?php 
$_smarty_tpl->ext->_inheritance->processBlock($_smarty_tpl, 0, "content", array (
  0 => 'block_2135936076571584118f8ea1_84083881',
  1 => false,
  3 => 0,
  2 => 0,
));
$_smarty_tpl->ext->_inheritance->endChild($_smarty_tpl);
$_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:layout.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 2, false);
}
/* {block 'localstyle'}  file:/Users/christopherschellberg/NetBeansProjects/FuelFlowerShop/fuel/app/views/member/createAccount.tpl */
function block_1986847628571584118eba55_98791135($_smarty_tpl, $_blockParentStack) {
?>

  <?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['asset_css'][0][0]->asset_css(array('refs'=>"table-display.css"),$_smarty_tpl);?>

  <style type='text/css'>
    .error { color: red; font-size: 80%; font-weight:bold; }
  </style>
<?php
}
/* {/block 'localstyle'} */
/* {block 'content'}  file:/Users/christopherschellberg/NetBeansProjects/FuelFlowerShop/fuel/app/views/member/createAccount.tpl */
function block_2135936076571584118f8ea1_84083881($_smarty_tpl, $_blockParentStack) {
?>

    <h2>Create an Account</h2>  
    <?php $_smarty_tpl->smarty->_cache['tag_stack'][] = array('form', array('attrs'=>array('action'=>$_smarty_tpl->tpl_vars['reentrantUrl']->value,'method'=>"post"))); $_block_repeat=true; echo $_smarty_tpl->smarty->registered_plugins['block']['form'][0][0]->form(array('attrs'=>array('action'=>$_smarty_tpl->tpl_vars['reentrantUrl']->value,'method'=>"post")), null, $_smarty_tpl, $_block_repeat);while ($_block_repeat) { ob_start();?>

    <table>
      <tr>
        <td>name:</td>
        <td>
          <input type="text" name="name" 
                 value="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['input_post'][0][0]->input_post(array('index'=>'name'),$_smarty_tpl);?>
" />
          <br />
          <span class="error"><?php echo $_smarty_tpl->tpl_vars['validator']->value->error_message('name');?>
</span>
        </td>
      </tr>
      <tr>
        <td>email: </td>
        <td>
          <input type="text" name="email" 
                 value="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['input_post'][0][0]->input_post(array('index'=>'email'),$_smarty_tpl);?>
" />
          <br />
          <span class="error"><?php echo $_smarty_tpl->tpl_vars['validator']->value->error_message('email');?>
</span>
        </td>
      </tr>
      <tr>
        <td>password: </td>
        <td>
          <input type="password" name="password" 
                 value="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['input_post'][0][0]->input_post(array('index'=>'password'),$_smarty_tpl);?>
" />
          <br />
          <span class="error"><?php echo $_smarty_tpl->tpl_vars['validator']->value->error_message('password');?>
</span>
        </td>
      </tr>
      <tr>
        <td>confirm: </td>
        <td>
          <input type="password" name="confirm" 
                 value="<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['input_post'][0][0]->input_post(array('index'=>'confirm'),$_smarty_tpl);?>
" />
          <br />
          <span class="error"><?php echo $_smarty_tpl->tpl_vars['validator']->value->error_message('confirm');?>
</span>
        </td>
      </tr>
      <tr>
        <td></td>
        <td><button type="submit" name="doit">Create</button>
            <button type="submit" name="cancel">Cancel</button>
        </td>
      </tr>
    </table>
    <h4 class="message"><?php echo (($tmp = @$_smarty_tpl->tpl_vars['message']->value)===null||$tmp==='' ? '' : $tmp);?>
</h4>
    <?php $_block_content = ob_get_clean(); $_block_repeat=false; echo $_smarty_tpl->smarty->registered_plugins['block']['form'][0][0]->form(array('attrs'=>array('action'=>$_smarty_tpl->tpl_vars['reentrantUrl']->value,'method'=>"post")), $_block_content, $_smarty_tpl, $_block_repeat); } array_pop($_smarty_tpl->smarty->_cache['tag_stack']);?>

<?php
}
/* {/block 'content'} */
}

<?php
/* Smarty version 3.1.29, created on 2016-04-25 19:19:30
  from "/Users/christopherschellberg/NetBeansProjects/FuelFlowerShop/fuel/app/views/home/showFlower.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_571e51a22016d0_88091552',
  'file_dependency' => 
  array (
    '021927e939a2d9aeac1b13be3681f80f9c9fc3bc' => 
    array (
      0 => '/Users/christopherschellberg/NetBeansProjects/FuelFlowerShop/fuel/app/views/home/showFlower.tpl',
      1 => 1461604766,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:layout.tpl' => 1,
  ),
),false)) {
function content_571e51a22016d0_88091552 ($_smarty_tpl) {
$_smarty_tpl->ext->_inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->ext->_inheritance->processBlock($_smarty_tpl, 0, "localstyle", array (
  0 => 'block_1648432531571e51a21c7a08_16678424',
  1 => false,
  3 => 0,
  2 => 0,
));
?>


<?php 
$_smarty_tpl->ext->_inheritance->processBlock($_smarty_tpl, 0, "content", array (
  0 => 'block_1174754154571e51a21cbf01_43352161',
  1 => false,
  3 => 0,
  2 => 0,
));
?>

<?php $_smarty_tpl->ext->_inheritance->endChild($_smarty_tpl);
$_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:layout.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 2, false);
}
/* {block 'localstyle'}  file:/Users/christopherschellberg/NetBeansProjects/FuelFlowerShop/fuel/app/views/home/showFlower.tpl */
function block_1648432531571e51a21c7a08_16678424($_smarty_tpl, $_blockParentStack) {
?>

  <style type="text/css">
    .showFlower {
      margin-top: 20px;
    }
    .showFlower tr {
      vertical-align: top;
    }
    .showFlower tr td:first-child {
      padding-right: 10px;
    }
    img.flower {
      width: 220px;
      height: 220px;
    }
  </style>
<?php
}
/* {/block 'localstyle'} */
/* {block 'content'}  file:/Users/christopherschellberg/NetBeansProjects/FuelFlowerShop/fuel/app/views/home/showFlower.tpl */
function block_1174754154571e51a21cbf01_43352161($_smarty_tpl, $_blockParentStack) {
?>


<table class='showFlower'>
    <tr>
        <td>
            <?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['asset_img'][0][0]->asset_img(array('refs'=>"flower/".((string)$_smarty_tpl->tpl_vars['flower']->value->imagefile),'attrs'=>array('class'=>'flower')),$_smarty_tpl);?>

        </td>
        <td>
            <b><?php echo $_smarty_tpl->tpl_vars['flower']->value->name;?>
 (#<?php echo $_smarty_tpl->tpl_vars['flower']->value->id;?>
)</b>
            <br />
            price: $<?php echo $_smarty_tpl->tpl_vars['flower']->value->price;?>

            <br />
            <br />
            <?php echo $_smarty_tpl->tpl_vars['flower']->value->description;?>

            <br />
            <br />
            <b>Cart</b>
            <?php $_smarty_tpl->smarty->_cache['tag_stack'][] = array('form', array('attrs'=>array('action'=>"show/addToCartReentrant/".((string)$_smarty_tpl->tpl_vars['flower']->value->id)))); $_block_repeat=true; echo $_smarty_tpl->smarty->registered_plugins['block']['form'][0][0]->form(array('attrs'=>array('action'=>"show/addToCartReentrant/".((string)$_smarty_tpl->tpl_vars['flower']->value->id))), null, $_smarty_tpl, $_block_repeat);while ($_block_repeat) { ob_start();?>

                <input type="hidden" name="flower_id" value="<?php echo $_smarty_tpl->tpl_vars['flower']->value->id;?>
"/>
                <input type="text" name="quantity" value="<?php echo (($tmp = @$_smarty_tpl->tpl_vars['quantity']->value)===null||$tmp==='' ? '' : $tmp);?>
"/>
                <button type="submit" name="setQuantity">Set Quantity</button>
                <button type="submit" name="clear">Clear</button>
                <br />
                <span class="error"><?php echo $_smarty_tpl->tpl_vars['validator']->value->error_message('quantity');?>
</span>
            <h4 class="message"><?php echo (($tmp = @$_smarty_tpl->tpl_vars['message']->value)===null||$tmp==='' ? '' : $tmp);?>
</h4>
            <?php $_block_content = ob_get_clean(); $_block_repeat=false; echo $_smarty_tpl->smarty->registered_plugins['block']['form'][0][0]->form(array('attrs'=>array('action'=>"show/addToCartReentrant/".((string)$_smarty_tpl->tpl_vars['flower']->value->id))), $_block_content, $_smarty_tpl, $_block_repeat); } array_pop($_smarty_tpl->smarty->_cache['tag_stack']);?>

            <?php if ($_smarty_tpl->tpl_vars['session']->value->get('member') && $_smarty_tpl->tpl_vars['session']->value->get('member')->is_admin) {?>
            <?php $_smarty_tpl->smarty->_cache['tag_stack'][] = array('form', array('attrs'=>array('action'=>"admin/modifyFlower/".((string)$_smarty_tpl->tpl_vars['flower']->value->id)))); $_block_repeat=true; echo $_smarty_tpl->smarty->registered_plugins['block']['form'][0][0]->form(array('attrs'=>array('action'=>"admin/modifyFlower/".((string)$_smarty_tpl->tpl_vars['flower']->value->id))), null, $_smarty_tpl, $_block_repeat);while ($_block_repeat) { ob_start();?>

                <input type="hidden" name="flower_id" value="<?php echo $_smarty_tpl->tpl_vars['flower']->value->id;?>
"/>
                <button type="submit" name="modifyFlower">Modify Flower</button>
            <?php $_block_content = ob_get_clean(); $_block_repeat=false; echo $_smarty_tpl->smarty->registered_plugins['block']['form'][0][0]->form(array('attrs'=>array('action'=>"admin/modifyFlower/".((string)$_smarty_tpl->tpl_vars['flower']->value->id))), $_block_content, $_smarty_tpl, $_block_repeat); } array_pop($_smarty_tpl->smarty->_cache['tag_stack']);?>

            <?php }?>
        </td>
    </tr>
</table>
<?php
}
/* {/block 'content'} */
}

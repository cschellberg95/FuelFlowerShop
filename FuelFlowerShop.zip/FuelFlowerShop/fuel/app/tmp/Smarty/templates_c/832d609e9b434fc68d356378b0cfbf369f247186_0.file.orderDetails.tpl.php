<?php
/* Smarty version 3.1.29, created on 2016-05-04 18:56:32
  from "/Users/christopherschellberg/NetBeansProjects/FuelFlowerShop/fuel/app/views/member/orderDetails.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_572a29c0b42038_25516512',
  'file_dependency' => 
  array (
    '832d609e9b434fc68d356378b0cfbf369f247186' => 
    array (
      0 => '/Users/christopherschellberg/NetBeansProjects/FuelFlowerShop/fuel/app/views/member/orderDetails.tpl',
      1 => 1462380986,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:layout.tpl' => 1,
  ),
),false)) {
function content_572a29c0b42038_25516512 ($_smarty_tpl) {
$_smarty_tpl->ext->_inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->ext->_inheritance->processBlock($_smarty_tpl, 0, "localstyle", array (
  0 => 'block_1964843640572a29c0a1d403_79580009',
  1 => false,
  3 => 0,
  2 => 0,
));
?>


<?php 
$_smarty_tpl->ext->_inheritance->processBlock($_smarty_tpl, 0, "content", array (
  0 => 'block_1745336709572a29c0a29057_77902647',
  1 => false,
  3 => 0,
  2 => 0,
));
$_smarty_tpl->ext->_inheritance->endChild($_smarty_tpl);
$_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:layout.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 2, false);
}
/* {block 'localstyle'}  file:/Users/christopherschellberg/NetBeansProjects/FuelFlowerShop/fuel/app/views/member/orderDetails.tpl */
function block_1964843640572a29c0a1d403_79580009($_smarty_tpl, $_blockParentStack) {
?>

  <?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['asset_css'][0][0]->asset_css(array('refs'=>"table-display.css"),$_smarty_tpl);?>

  <style type='text/css'>
  </style>
<?php
}
/* {/block 'localstyle'} */
/* {block 'content'}  file:/Users/christopherschellberg/NetBeansProjects/FuelFlowerShop/fuel/app/views/member/orderDetails.tpl */
function block_1745336709572a29c0a29057_77902647($_smarty_tpl, $_blockParentStack) {
?>


  <h2><?php echo $_smarty_tpl->tpl_vars['page_title']->value;?>
</h2>
<?php if ($_smarty_tpl->tpl_vars['session']->value->get('member') && $_smarty_tpl->tpl_vars['session']->value->get('member')->is_admin) {?>
    <tr>
        Member: <?php echo $_smarty_tpl->tpl_vars['member_name']->value;?>

        </br>
        Email: <?php echo $_smarty_tpl->tpl_vars['member_email']->value;?>

    </tr>
<?php }?>
<table class='orderDetails' frame='hsides'>
    <tr> 
        <th>name</th>
        <th>price</th>
        <th>quantity</th>
        <?php if ($_smarty_tpl->tpl_vars['session']->value->get('member') && $_smarty_tpl->tpl_vars['session']->value->get('member')->is_admin) {?>
        <td></td>
        <th>In stock</th>
        <?php }?>
    </tr>
    <?php
$_from = $_smarty_tpl->tpl_vars['item_data']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$__foreach_item_id_0_saved_item = isset($_smarty_tpl->tpl_vars['item_id']) ? $_smarty_tpl->tpl_vars['item_id'] : false;
$_smarty_tpl->tpl_vars['item_id'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['item_id']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['item_id']->value) {
$_smarty_tpl->tpl_vars['item_id']->_loop = true;
$__foreach_item_id_0_saved_local_item = $_smarty_tpl->tpl_vars['item_id'];
?>
    <tr>
        <td><?php echo $_smarty_tpl->tpl_vars['item_id']->value['name'];?>
</td>
        <td>$<?php echo number_format($_smarty_tpl->tpl_vars['item_id']->value['price'],2,".",'');?>
</td>
        <td><?php echo $_smarty_tpl->tpl_vars['item_id']->value['quantity'];?>
</td>
        <td>$<?php echo number_format($_smarty_tpl->tpl_vars['item_id']->value['sub_total'],2,".",'');?>
</td>
        <?php if ($_smarty_tpl->tpl_vars['session']->value->get('member') && $_smarty_tpl->tpl_vars['session']->value->get('member')->is_admin) {?>
        <td><?php echo $_smarty_tpl->tpl_vars['item_id']->value['instock'];?>
</td>
        <?php }?>
    </tr>
    <?php
$_smarty_tpl->tpl_vars['item_id'] = $__foreach_item_id_0_saved_local_item;
}
if ($__foreach_item_id_0_saved_item) {
$_smarty_tpl->tpl_vars['item_id'] = $__foreach_item_id_0_saved_item;
}
?>
    <tr>
        <th>Total:</th>
        <td></td>
        <td><th>$<?php echo $_smarty_tpl->tpl_vars['total_price']->value;?>
</th></td>
    </tr>
</table>
<?php if ($_smarty_tpl->tpl_vars['session']->value->get('member') && $_smarty_tpl->tpl_vars['session']->value->get('member')->is_admin) {?>
<div class='action super'>
    <?php $_smarty_tpl->smarty->_cache['tag_stack'][] = array('form', array('attrs'=>array('action'=>"admin/processOrder/".((string)$_smarty_tpl->tpl_vars['item_id']->value['basket_id'])))); $_block_repeat=true; echo $_smarty_tpl->smarty->registered_plugins['block']['form'][0][0]->form(array('attrs'=>array('action'=>"admin/processOrder/".((string)$_smarty_tpl->tpl_vars['item_id']->value['basket_id']))), null, $_smarty_tpl, $_block_repeat);while ($_block_repeat) { ob_start();?>

        <button type="submit" name="processOrder">Process Order</button>
        <input type='hidden' name='confirm' value='<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['session_get_flash'][0][0]->session_get_flash(array('var'=>'confirm'),$_smarty_tpl);?>
' />
    <?php $_block_content = ob_get_clean(); $_block_repeat=false; echo $_smarty_tpl->smarty->registered_plugins['block']['form'][0][0]->form(array('attrs'=>array('action'=>"admin/processOrder/".((string)$_smarty_tpl->tpl_vars['item_id']->value['basket_id']))), $_block_content, $_smarty_tpl, $_block_repeat); } array_pop($_smarty_tpl->smarty->_cache['tag_stack']);?>

</div>
<?php }?>
<h4 class="message"><?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['session_get_flash'][0][0]->session_get_flash(array('var'=>'message'),$_smarty_tpl);?>
</h4>
<?php
}
/* {/block 'content'} */
}

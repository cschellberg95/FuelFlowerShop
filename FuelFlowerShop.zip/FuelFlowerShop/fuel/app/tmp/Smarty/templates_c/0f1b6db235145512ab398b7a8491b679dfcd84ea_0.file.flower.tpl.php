<?php
/* Smarty version 3.1.29, created on 2016-04-22 00:52:29
  from "/Users/christopherschellberg/NetBeansProjects/FuelFlowerShop/fuel/app/views/admin/flower.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_571959ad1ed043_74206541',
  'file_dependency' => 
  array (
    '0f1b6db235145512ab398b7a8491b679dfcd84ea' => 
    array (
      0 => '/Users/christopherschellberg/NetBeansProjects/FuelFlowerShop/fuel/app/views/admin/flower.tpl',
      1 => 1461279145,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:layout.tpl' => 1,
  ),
),false)) {
function content_571959ad1ed043_74206541 ($_smarty_tpl) {
$_smarty_tpl->ext->_inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->ext->_inheritance->processBlock($_smarty_tpl, 0, 'localstyle', array (
  0 => 'block_30131412571959ad182df7_16532222',
  1 => false,
  3 => 0,
  2 => 0,
));
?>


<?php 
$_smarty_tpl->ext->_inheritance->processBlock($_smarty_tpl, 0, "content", array (
  0 => 'block_1074112047571959ad18cef3_28328863',
  1 => false,
  3 => 0,
  2 => 0,
));
$_smarty_tpl->ext->_inheritance->endChild($_smarty_tpl);
$_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:layout.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 2, false);
}
/* {block 'localstyle'}  file:/Users/christopherschellberg/NetBeansProjects/FuelFlowerShop/fuel/app/views/admin/flower.tpl */
function block_30131412571959ad182df7_16532222($_smarty_tpl, $_blockParentStack) {
?>

  <?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['asset_css'][0][0]->asset_css(array('refs'=>"table-display.css"),$_smarty_tpl);?>

  <style type='text/css'>
    .error { color: red; font-size: 80%; font-weight:bold; }
  </style>
<?php
}
/* {/block 'localstyle'} */
/* {block 'content'}  file:/Users/christopherschellberg/NetBeansProjects/FuelFlowerShop/fuel/app/views/admin/flower.tpl */
function block_1074112047571959ad18cef3_28328863($_smarty_tpl, $_blockParentStack) {
?>

  <h2><?php echo $_smarty_tpl->tpl_vars['page_title']->value;?>
</h2>
 
  <?php $_smarty_tpl->smarty->_cache['tag_stack'][] = array('form', array('attrs'=>array('action'=>$_smarty_tpl->tpl_vars['reentrantUrl']->value))); $_block_repeat=true; echo $_smarty_tpl->smarty->registered_plugins['block']['form'][0][0]->form(array('attrs'=>array('action'=>$_smarty_tpl->tpl_vars['reentrantUrl']->value)), null, $_smarty_tpl, $_block_repeat);while ($_block_repeat) { ob_start();?>

    <table>
      <tr>
        <td>name: </td>
        <td>
          <?php if ($_smarty_tpl->tpl_vars['reentrantUrl']->value !== "admin/addFlowerReentrant") {?>
            <input type="hidden" name="name" value="<?php echo (($tmp = @$_smarty_tpl->tpl_vars['name']->value)===null||$tmp==='' ? '' : $tmp);?>
"/>
            <?php echo (($tmp = @$_smarty_tpl->tpl_vars['name']->value)===null||$tmp==='' ? '' : $tmp);?>

            <br />
            <span class="error"><?php echo $_smarty_tpl->tpl_vars['validator']->value->error_message('name');?>
</span>
          <?php } else { ?>
            <input type="text" name="name" value="<?php echo (($tmp = @$_smarty_tpl->tpl_vars['name']->value)===null||$tmp==='' ? '' : $tmp);?>
"/>
            <br />
            <span class="error"><?php echo $_smarty_tpl->tpl_vars['validator']->value->error_message('name');?>
</span>
          <?php }?>
        </td>
      </tr>
      <tr>
        <td>price: </td>
        <td>
          <input type="text" name="price" value="<?php echo (($tmp = @$_smarty_tpl->tpl_vars['price']->value)===null||$tmp==='' ? '' : $tmp);?>
"  />
          <br />
          <span class="error"><?php echo $_smarty_tpl->tpl_vars['validator']->value->error_message('price');?>
</span>
        </td>
      </tr>
      <tr>
        <td>description: </td>
        <td>
          <textarea type="text" name="description" rows="3" cols="65" value="<?php echo (($tmp = @$_smarty_tpl->tpl_vars['description']->value)===null||$tmp==='' ? '' : $tmp);?>
"><?php echo (($tmp = @$_smarty_tpl->tpl_vars['description']->value)===null||$tmp==='' ? '' : $tmp);?>
</textarea>
          <br />
          <span class="error"><?php echo $_smarty_tpl->tpl_vars['validator']->value->error_message('description');?>
</span>
        </td>
      </tr>
      <tr>
        <td>Imagefile: </td>
        <td>
          <input type="text" name="imagefile" value="<?php echo (($tmp = @$_smarty_tpl->tpl_vars['imagefile']->value)===null||$tmp==='' ? '' : $tmp);?>
" />
          <br />
          <span class="error"><?php echo $_smarty_tpl->tpl_vars['validator']->value->error_message('imagefile');?>
</span>
        </td>
      </tr>
      <tr>
        <td>instock: </td>
        <td>
        <input type="text" name="instock" value="<?php echo (($tmp = @$_smarty_tpl->tpl_vars['instock']->value)===null||$tmp==='' ? '' : $tmp);?>
"  />
        <br />
        <span class="error"><?php echo $_smarty_tpl->tpl_vars['validator']->value->error_message('instock');?>
</span>
        </td>
      </tr>
      <tr>
        <td></td>
        <td>
          <button type="submit" name="doit">Submit</button>
          <button type="submit" name="cancel">Cancel</button>
        </td>
      </tr>
    </table>
 
    <h4 class="message"><?php echo (($tmp = @$_smarty_tpl->tpl_vars['message']->value)===null||$tmp==='' ? '' : $tmp);?>
</h4>
  <?php $_block_content = ob_get_clean(); $_block_repeat=false; echo $_smarty_tpl->smarty->registered_plugins['block']['form'][0][0]->form(array('attrs'=>array('action'=>$_smarty_tpl->tpl_vars['reentrantUrl']->value)), $_block_content, $_smarty_tpl, $_block_repeat); } array_pop($_smarty_tpl->smarty->_cache['tag_stack']);?>

<?php
}
/* {/block 'content'} */
}

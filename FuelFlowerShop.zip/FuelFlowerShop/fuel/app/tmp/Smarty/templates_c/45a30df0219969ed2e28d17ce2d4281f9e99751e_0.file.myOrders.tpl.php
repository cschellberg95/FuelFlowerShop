<?php
/* Smarty version 3.1.29, created on 2016-04-25 22:32:36
  from "/Users/christopherschellberg/NetBeansProjects/FuelFlowerShop/fuel/app/views/member/myOrders.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_571e7ee4cd28d9_58420049',
  'file_dependency' => 
  array (
    '45a30df0219969ed2e28d17ce2d4281f9e99751e' => 
    array (
      0 => '/Users/christopherschellberg/NetBeansProjects/FuelFlowerShop/fuel/app/views/member/myOrders.tpl',
      1 => 1461616187,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:layout.tpl' => 1,
  ),
),false)) {
function content_571e7ee4cd28d9_58420049 ($_smarty_tpl) {
$_smarty_tpl->ext->_inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->ext->_inheritance->processBlock($_smarty_tpl, 0, "localstyle", array (
  0 => 'block_1904965101571e7ee4ccb954_34147336',
  1 => false,
  3 => 0,
  2 => 0,
));
?>


<?php 
$_smarty_tpl->ext->_inheritance->processBlock($_smarty_tpl, 0, "content", array (
  0 => 'block_825300730571e7ee4cd0ed2_89361340',
  1 => false,
  3 => 0,
  2 => 0,
));
$_smarty_tpl->ext->_inheritance->endChild($_smarty_tpl);
$_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:layout.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 2, false);
}
/* {block 'localstyle'}  file:/Users/christopherschellberg/NetBeansProjects/FuelFlowerShop/fuel/app/views/member/myOrders.tpl */
function block_1904965101571e7ee4ccb954_34147336($_smarty_tpl, $_blockParentStack) {
?>

  <?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['asset_css'][0][0]->asset_css(array('refs'=>"table-display.css"),$_smarty_tpl);?>

  <style type='text/css'>
  </style>
<?php
}
/* {/block 'localstyle'} */
/* {block 'content'}  file:/Users/christopherschellberg/NetBeansProjects/FuelFlowerShop/fuel/app/views/member/myOrders.tpl */
function block_825300730571e7ee4cd0ed2_89361340($_smarty_tpl, $_blockParentStack) {
?>


  <h2>My Orders</h2>
<?php
}
/* {/block 'content'} */
}

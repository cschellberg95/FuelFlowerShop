<?php
/* Smarty version 3.1.29, created on 2016-05-02 22:06:37
  from "/Users/christopherschellberg/NetBeansProjects/FuelFlowerShop/fuel/app/views/home/index.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5727b34db294e6_23068567',
  'file_dependency' => 
  array (
    '05a28e52bce542e40a2e50b006be27e154121416' => 
    array (
      0 => '/Users/christopherschellberg/NetBeansProjects/FuelFlowerShop/fuel/app/views/home/index.tpl',
      1 => 1462219592,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:layout.tpl' => 1,
  ),
),false)) {
function content_5727b34db294e6_23068567 ($_smarty_tpl) {
$_smarty_tpl->ext->_inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->ext->_inheritance->processBlock($_smarty_tpl, 0, 'localstyle', array (
  0 => 'block_15902251295727b34dace748_83443880',
  1 => false,
  3 => 0,
  2 => 0,
));
?>


<?php 
$_smarty_tpl->ext->_inheritance->processBlock($_smarty_tpl, 0, "content", array (
  0 => 'block_10484989855727b34dad5a36_65954323',
  1 => false,
  3 => 0,
  2 => 0,
));
?>

<?php $_smarty_tpl->ext->_inheritance->endChild($_smarty_tpl);
$_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:layout.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 2, false);
}
/* {block 'localstyle'}  file:/Users/christopherschellberg/NetBeansProjects/FuelFlowerShop/fuel/app/views/home/index.tpl */
function block_15902251295727b34dace748_83443880($_smarty_tpl, $_blockParentStack) {
?>

  <style type='text/css'>
    img.flower {
      width: 50px;
      height: 50px;
    }
    .showFlowers tr td:first-child {
      padding-right: 10px;
    }
    .setOrder {
      position: absolute;
      top: 10px;
      right: 10px;
    }
  </style>
<?php
}
/* {/block 'localstyle'} */
/* {block 'content'}  file:/Users/christopherschellberg/NetBeansProjects/FuelFlowerShop/fuel/app/views/home/index.tpl */
function block_10484989855727b34dad5a36_65954323($_smarty_tpl, $_blockParentStack) {
?>

  <h2>Listing (by <?php echo $_smarty_tpl->tpl_vars['order']->value;?>
)</h2>

  <?php $_smarty_tpl->smarty->_cache['tag_stack'][] = array('form', array('attrs'=>array('class'=>'setOrder','action'=>'show/setOrder','method'=>"post"))); $_block_repeat=true; echo $_smarty_tpl->smarty->registered_plugins['block']['form'][0][0]->form(array('attrs'=>array('class'=>'setOrder','action'=>'show/setOrder','method'=>"post")), null, $_smarty_tpl, $_block_repeat);while ($_block_repeat) { ob_start();?>

    <input type="submit" name="submit" value="list by:"/>
    <select name="order">
        <option value="name" <?php if ($_smarty_tpl->tpl_vars['order']->value == "name") {?>selected<?php }?>>name</option>
        <option value="price"<?php if ($_smarty_tpl->tpl_vars['order']->value == "price") {?>selected<?php }?>>price</option>
    </select>
  <?php $_block_content = ob_get_clean(); $_block_repeat=false; echo $_smarty_tpl->smarty->registered_plugins['block']['form'][0][0]->form(array('attrs'=>array('class'=>'setOrder','action'=>'show/setOrder','method'=>"post")), $_block_content, $_smarty_tpl, $_block_repeat); } array_pop($_smarty_tpl->smarty->_cache['tag_stack']);?>


  <table class='showFlowers'>
    <?php
$_from = $_smarty_tpl->tpl_vars['flowers']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$__foreach_flower_0_saved_item = isset($_smarty_tpl->tpl_vars['flower']) ? $_smarty_tpl->tpl_vars['flower'] : false;
$_smarty_tpl->tpl_vars['flower'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['flower']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['flower']->value) {
$_smarty_tpl->tpl_vars['flower']->_loop = true;
$__foreach_flower_0_saved_local_item = $_smarty_tpl->tpl_vars['flower'];
?>
      <tr>
        <td>
          <?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['html_anchor'][0][0]->html_anchor(array('href'=>"/show/flower/".((string)$_smarty_tpl->tpl_vars['flower']->value->id),'text'=>((string)$_smarty_tpl->tpl_vars['flower']->value->name)),$_smarty_tpl);?>

          <br />
          price: $<?php echo sprintf("%.2f",$_smarty_tpl->tpl_vars['flower']->value->price);?>

          <?php if ($_smarty_tpl->tpl_vars['session']->value->get('member') && $_smarty_tpl->tpl_vars['session']->value->get('member')->is_admin) {?>
              instock: <?php echo $_smarty_tpl->tpl_vars['flower']->value->instock;?>

          <?php }?>
        </td>

        <td>
          <?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['asset_img'][0][0]->asset_img(array('refs'=>"flower/".((string)$_smarty_tpl->tpl_vars['flower']->value->imagefile),'attrs'=>array('class'=>'flower')),$_smarty_tpl);?>

        </td>
      </tr>
    <?php
$_smarty_tpl->tpl_vars['flower'] = $__foreach_flower_0_saved_local_item;
}
if ($__foreach_flower_0_saved_item) {
$_smarty_tpl->tpl_vars['flower'] = $__foreach_flower_0_saved_item;
}
?>
  </table>

<?php
}
/* {/block 'content'} */
}

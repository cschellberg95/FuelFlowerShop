<?php
/* Smarty version 3.1.29, created on 2016-04-25 22:42:45
  from "/Users/christopherschellberg/NetBeansProjects/FuelFlowerShop/fuel/app/views/links.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_571e81453e2574_43811262',
  'file_dependency' => 
  array (
    'cbb10054da5662e37267e45dcb84a6408285082c' => 
    array (
      0 => '/Users/christopherschellberg/NetBeansProjects/FuelFlowerShop/fuel/app/views/links.tpl',
      1 => 1461616961,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_571e81453e2574_43811262 ($_smarty_tpl) {
?>
<li><?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['html_anchor'][0][0]->html_anchor(array('href'=>"/",'text'=>"Home"),$_smarty_tpl);?>
</li>
<li><?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['html_anchor'][0][0]->html_anchor(array('href'=>"/show/cart",'text'=>"Cart"),$_smarty_tpl);?>
</li>

<?php if ($_smarty_tpl->tpl_vars['session']->value->get('member') && $_smarty_tpl->tpl_vars['session']->value->get('member')->is_admin) {?>
  <li><?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['html_anchor'][0][0]->html_anchor(array('href'=>'/admin/addFlower','text'=>'Add Flower'),$_smarty_tpl);?>
</li>
<?php }?>

<?php if (empty($_smarty_tpl->tpl_vars['session']->value->get('member'))) {?>
  <li><?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['html_anchor'][0][0]->html_anchor(array('href'=>'/home/createAccount','text'=>'Create Account'),$_smarty_tpl);?>
</li>
<?php }?>

<?php if ($_smarty_tpl->tpl_vars['session']->value->get('member') && !$_smarty_tpl->tpl_vars['session']->value->get('member')->is_admin) {?>
    <li><?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['html_anchor'][0][0]->html_anchor(array('href'=>'/member/myOrders','text'=>'My Orders'),$_smarty_tpl);?>
</li>
<?php }?>

<?php if ($_smarty_tpl->tpl_vars['session']->value->get('member') && $_smarty_tpl->tpl_vars['session']->value->get('member')->is_admin) {?>
    <li><?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['html_anchor'][0][0]->html_anchor(array('href'=>'/admin/allOrders','text'=>'All Orders'),$_smarty_tpl);?>
</li>
<?php }?>

<?php if ($_smarty_tpl->tpl_vars['session']->value->get('member')) {?>
  <li><?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['html_anchor'][0][0]->html_anchor(array('href'=>'/authenticate/logout','text'=>'Logout'),$_smarty_tpl);?>
</li>
<?php } else { ?>
  <li><?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['html_anchor'][0][0]->html_anchor(array('href'=>'/authenticate/login','text'=>'Login'),$_smarty_tpl);?>
</li>
<?php }
}
}

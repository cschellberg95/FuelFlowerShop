<?php
/* Smarty version 3.1.29, created on 2016-05-04 19:28:03
  from "/Users/christopherschellberg/NetBeansProjects/FuelFlowerShop/fuel/app/views/layout.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_572a3123a32362_41675246',
  'file_dependency' => 
  array (
    'de71610c8ef01367751d8b8b7c73930c4b848ee1' => 
    array (
      0 => '/Users/christopherschellberg/NetBeansProjects/FuelFlowerShop/fuel/app/views/layout.tpl',
      1 => 1462382879,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:links.tpl' => 1,
  ),
),false)) {
function content_572a3123a32362_41675246 ($_smarty_tpl) {
$_smarty_tpl->ext->_inheritance->init($_smarty_tpl, false);
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>  
      <?php ob_start();
ob_start();
echo Uri::base(array(),$_smarty_tpl);
echo basename(dirname(ob_get_clean()));
$_tmp1=ob_get_clean();
echo (($tmp = @$_smarty_tpl->tpl_vars['page_title']->value)===null||$tmp==='' ? $_tmp1 : $tmp);?>

    </title>
    <?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['asset_css'][0][0]->asset_css(array('refs'=>"nav.css"),$_smarty_tpl);?>

    <?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['asset_css'][0][0]->asset_css(array('refs'=>"layout.css"),$_smarty_tpl);?>

    <?php 
$_smarty_tpl->ext->_inheritance->processBlock($_smarty_tpl, 0, "localstyle", array (
  0 => 'block_1608220011572a3123a1ac32_29266511',
  1 => false,
  3 => 0,
  2 => 0,
));
?>

  </head>
  <body>
  <main>

  <header>
    <?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['asset_img'][0][0]->asset_img(array('refs'=>"header.png"),$_smarty_tpl);?>

    <span class="caption"><?php echo (($tmp = @$_smarty_tpl->tpl_vars['session']->value->get('member')->name)===null||$tmp==='' ? '' : $tmp);?>
</span>
  </header>
    
  <nav>
  <ul>
  <li>
    <a href="#" class="no-action">
      <?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['asset_img'][0][0]->asset_img(array('attrs'=>array('class'=>"menu"),'refs'=>"menu.png"),$_smarty_tpl);?>

    </a>
  <ul>
  <?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:links.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

  </ul>
  </li>
  </ul>
  </nav>
  
  <section>
    <?php 
$_smarty_tpl->ext->_inheritance->processBlock($_smarty_tpl, 0, "content", array (
  0 => 'block_1091075795572a3123a2f5d8_22346268',
  1 => false,
  3 => 0,
  2 => 0,
));
?>

  </section>
  
  </main>
  <?php echo '<script'; ?>
 type="text/javascript">window.onunload = function(){}<?php echo '</script'; ?>
>
  </body>
</html>
<?php }
/* {block 'localstyle'}  file:layout.tpl */
function block_1608220011572a3123a1ac32_29266511($_smarty_tpl, $_blockParentStack) {
}
/* {/block 'localstyle'} */
/* {block 'content'}  file:layout.tpl */
function block_1091075795572a3123a2f5d8_22346268($_smarty_tpl, $_blockParentStack) {
}
/* {/block 'content'} */
}

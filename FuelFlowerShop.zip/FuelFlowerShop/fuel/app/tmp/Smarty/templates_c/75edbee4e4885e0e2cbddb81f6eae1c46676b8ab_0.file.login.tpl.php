<?php
/* Smarty version 3.1.29, created on 2016-04-18 21:11:22
  from "/Users/christopherschellberg/NetBeansProjects/FuelFlowerShop/fuel/app/views/authenticate/login.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5715315a146650_84028201',
  'file_dependency' => 
  array (
    '75edbee4e4885e0e2cbddb81f6eae1c46676b8ab' => 
    array (
      0 => '/Users/christopherschellberg/NetBeansProjects/FuelFlowerShop/fuel/app/views/authenticate/login.tpl',
      1 => 1461006679,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:layout.tpl' => 1,
  ),
),false)) {
function content_5715315a146650_84028201 ($_smarty_tpl) {
$_smarty_tpl->ext->_inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->ext->_inheritance->processBlock($_smarty_tpl, 0, "localstyle", array (
  0 => 'block_19895789645715315a12a846_33742447',
  1 => false,
  3 => 0,
  2 => 0,
));
?>


<?php 
$_smarty_tpl->ext->_inheritance->processBlock($_smarty_tpl, 0, "content", array (
  0 => 'block_3866744595715315a132825_00857907',
  1 => false,
  3 => 0,
  2 => 0,
));
$_smarty_tpl->ext->_inheritance->endChild($_smarty_tpl);
$_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:layout.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 2, false);
}
/* {block 'localstyle'}  file:/Users/christopherschellberg/NetBeansProjects/FuelFlowerShop/fuel/app/views/authenticate/login.tpl */
function block_19895789645715315a12a846_33742447($_smarty_tpl, $_blockParentStack) {
?>

<?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['asset_css'][0][0]->asset_css(array('refs'=>"table-display.css"),$_smarty_tpl);?>

<?php
}
/* {/block 'localstyle'} */
/* {block 'content'}  file:/Users/christopherschellberg/NetBeansProjects/FuelFlowerShop/fuel/app/views/authenticate/login.tpl */
function block_3866744595715315a132825_00857907($_smarty_tpl, $_blockParentStack) {
?>

<h2>Login</h2>
 
<p>Please enter access information</p>
<?php $_smarty_tpl->smarty->_cache['tag_stack'][] = array('form', array('attrs'=>array('action'=>'/authenticate/validate'))); $_block_repeat=true; echo $_smarty_tpl->smarty->registered_plugins['block']['form'][0][0]->form(array('attrs'=>array('action'=>'/authenticate/validate')), null, $_smarty_tpl, $_block_repeat);while ($_block_repeat) { ob_start();?>

  <table>
    <tr>
      <th>user:</th>
      <td><input type="text" name="username" autofocus="on"
                 value="<?php echo (($tmp = @$_smarty_tpl->tpl_vars['username']->value)===null||$tmp==='' ? '' : $tmp);?>
" /></td>
    </tr>
    <tr>
      <th>password:</th>
      <td><input type="password" name="password" /></td>
    </tr>
    <tr>
      <td></td>
      <td><button type="submit">Access</button></td>
    </tr>
  </table>  
<?php $_block_content = ob_get_clean(); $_block_repeat=false; echo $_smarty_tpl->smarty->registered_plugins['block']['form'][0][0]->form(array('attrs'=>array('action'=>'/authenticate/validate')), $_block_content, $_smarty_tpl, $_block_repeat); } array_pop($_smarty_tpl->smarty->_cache['tag_stack']);?>

 
<h4 class="message"><?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['session_get_flash'][0][0]->session_get_flash(array('var'=>'message'),$_smarty_tpl);?>
</h4>
<?php
}
/* {/block 'content'} */
}

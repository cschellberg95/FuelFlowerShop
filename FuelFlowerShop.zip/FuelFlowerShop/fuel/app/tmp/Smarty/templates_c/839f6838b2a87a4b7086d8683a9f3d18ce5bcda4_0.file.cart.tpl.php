<?php
/* Smarty version 3.1.29, created on 2016-04-26 22:44:43
  from "/Users/christopherschellberg/NetBeansProjects/FuelFlowerShop/fuel/app/views/home/cart.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_571fd33b4da091_46535836',
  'file_dependency' => 
  array (
    '839f6838b2a87a4b7086d8683a9f3d18ce5bcda4' => 
    array (
      0 => '/Users/christopherschellberg/NetBeansProjects/FuelFlowerShop/fuel/app/views/home/cart.tpl',
      1 => 1461703477,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:layout.tpl' => 1,
  ),
),false)) {
function content_571fd33b4da091_46535836 ($_smarty_tpl) {
$_smarty_tpl->ext->_inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->ext->_inheritance->processBlock($_smarty_tpl, 0, "localstyle", array (
  0 => 'block_218096705571fd33b476393_35010399',
  1 => false,
  3 => 0,
  2 => 0,
));
?>


<?php 
$_smarty_tpl->ext->_inheritance->processBlock($_smarty_tpl, 0, "content", array (
  0 => 'block_1988387930571fd33b481d09_03979781',
  1 => false,
  3 => 0,
  2 => 0,
));
?>

<?php $_smarty_tpl->ext->_inheritance->endChild($_smarty_tpl);
$_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:layout.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 2, false);
}
/* {block 'localstyle'}  file:/Users/christopherschellberg/NetBeansProjects/FuelFlowerShop/fuel/app/views/home/cart.tpl */
function block_218096705571fd33b476393_35010399($_smarty_tpl, $_blockParentStack) {
?>

  <?php echo $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['asset_css'][0][0]->asset_css(array('refs'=>"table-display.css"),$_smarty_tpl);?>

  <style type='text/css'>
  </style>
<?php
}
/* {/block 'localstyle'} */
/* {block 'content'}  file:/Users/christopherschellberg/NetBeansProjects/FuelFlowerShop/fuel/app/views/home/cart.tpl */
function block_1988387930571fd33b481d09_03979781($_smarty_tpl, $_blockParentStack) {
?>


  <h2>My Cart</h2>
<?php if ($_smarty_tpl->tpl_vars['message']->value == 'Cart is empty') {?>
    <tr><?php echo $_smarty_tpl->tpl_vars['message']->value;?>
</tr>
<?php } else { ?>
<table class='cart' frame='hsides'>
    <tr> 
        <th>name</th>
        <th>price</th>
        <th>quantity</th>
    </tr>
    <?php
$_from = $_smarty_tpl->tpl_vars['cart_data']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$__foreach_flower_id_0_saved_item = isset($_smarty_tpl->tpl_vars['flower_id']) ? $_smarty_tpl->tpl_vars['flower_id'] : false;
$_smarty_tpl->tpl_vars['flower_id'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['flower_id']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['flower_id']->value) {
$_smarty_tpl->tpl_vars['flower_id']->_loop = true;
$__foreach_flower_id_0_saved_local_item = $_smarty_tpl->tpl_vars['flower_id'];
?>
    <tr>
        <td>
            <a href="flower/<?php echo $_smarty_tpl->tpl_vars['flower_id']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['flower_id']->value['name'];?>
</a>
        </td>
        <td>$<?php echo number_format($_smarty_tpl->tpl_vars['flower_id']->value['price'],2,".",'');?>
</td>
        <td><?php echo $_smarty_tpl->tpl_vars['flower_id']->value['quantity'];?>
</td>
        <td>$<?php echo number_format($_smarty_tpl->tpl_vars['flower_id']->value['sub_total'],2,".",'');?>
</td>
    </tr>
    <?php
$_smarty_tpl->tpl_vars['flower_id'] = $__foreach_flower_id_0_saved_local_item;
}
if ($__foreach_flower_id_0_saved_item) {
$_smarty_tpl->tpl_vars['flower_id'] = $__foreach_flower_id_0_saved_item;
}
?>
    <tr>
        <th>Total:</th>
        <td></td>
        <td><th>$<?php echo $_smarty_tpl->tpl_vars['total_price']->value;?>
</th></td>
    </tr>
</table>
<?php if ($_smarty_tpl->tpl_vars['session']->value->get('member')) {?>
    <?php $_smarty_tpl->smarty->_cache['tag_stack'][] = array('form', array('attrs'=>array('action'=>"show/placeOrder"))); $_block_repeat=true; echo $_smarty_tpl->smarty->registered_plugins['block']['form'][0][0]->form(array('attrs'=>array('action'=>"show/placeOrder")), null, $_smarty_tpl, $_block_repeat);while ($_block_repeat) { ob_start();?>

        <button type="submit" name="placeOrder">Place Order</button>
    <?php $_block_content = ob_get_clean(); $_block_repeat=false; echo $_smarty_tpl->smarty->registered_plugins['block']['form'][0][0]->form(array('attrs'=>array('action'=>"show/placeOrder")), $_block_content, $_smarty_tpl, $_block_repeat); } array_pop($_smarty_tpl->smarty->_cache['tag_stack']);?>

<?php }
}
}
/* {/block 'content'} */
}

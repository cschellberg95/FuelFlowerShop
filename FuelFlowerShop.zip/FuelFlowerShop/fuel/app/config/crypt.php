<?php
return array(
  'crypto_key' => 'Gj0m80etE3n4tLc9_0kUARa4',
  'crypto_iv' => 'YtQrH4zg80E8PCQVJ0ies4H0',
  'crypto_hmac' => 'l3ArRss6U3dgaAIwi4BiYYes',
);

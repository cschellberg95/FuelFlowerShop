<?php
 
class Controller_Authenticate extends Controller_Base {
 
  public function action_login() {
    if (!is_null($this->sessionMember)) {
      return Response::redirect("/");
    }
    $data = array(
      'username' => Session::get_flash('username'),
      'message' => Session::get_flash('message'),
    );
    return Response::forge(View::forge("authenticate/login.tpl", $data));
  }
 
  public function action_validate() {
    $username = trim(Input::post('username'));
    $password = trim(Input::post('password'));
    $member = Model_Member::find('first', [
        'where'=> array( "name" => $username )
    ]);
    if (is_null($member)) {
      Session::set_flash('username', $username);
      Session::set_flash('message', 'invalid user');
      return Response::redirect('/authenticate/login');
    }
    elseif (hash('sha256', $password) === $member->password) {
      $sessMember = (object) [
         'id' => $member->id,
         'name' => $member->name,
         'is_admin' => $member->is_admin,
      ];
      Session::set('member', $sessMember);
      return Response::redirect('/');      
    }
    else {
      Session::set_flash('username', $username);
      Session::set_flash('message', 'invalid password');
      return Response::redirect('/authenticate/login');
    }
  }
 
  public function action_logout() {
    Session::delete('member');
    return Response::redirect('/');      
  }
 
  public function action_noaccess() {
    return Response::forge(View::forge("authenticate/noAccess.tpl"));
  }
}
<?php

class Controller_Admin extends Controller_Base {
    
    public function before() {
        parent::before();
        if (is_null($this->sessionMember)) {
            return Response::redirect('/authenticate/login');
        }
        if (!$this->sessionMember->is_admin) {
            return Response::redirect('/authenticate/noAccess');
        } 
    }
 
    private function flowerValidator() {
        
        //validation flag variable for name
        //which allows only letters and spaces
        $flags = array('alpha', 'spaces');
        $validator = Validation::forge();
        $validator->add('name', 'name')
          ->add_rule('trim')
          ->add_rule('required')
          ->add_rule('min_length', 6)
          ->add_rule('valid_string', $flags)
        ;
        $validator->add('price', 'price')
          ->add_rule('trim')
          ->add_rule('required')
          ->add_rule('is_numeric')
          ->add_rule('match_pattern', '/^[+]?([.]\d+|\d+([.]\d+)?)$/')
        ;
        $validator->add('instock', 'instock')
          ->add_rule('trim')
          ->add_rule('required')
          ->add_rule('match_pattern', '/^\d+$/')
          ->add_rule('numeric_min', 1)
        ;
        // enter all fields into validator, regardless of whether
        // they can generate errors or not
        $validator->add('description', 'description');
        $validator->add('imagefile', 'imagefile');

        // modify error messages
        $validator
          ->set_message('required', ':label cannot be empty')
          ->set_message('min_length', 'at least :param:1 char(s)')
        ;
        $validator
          ->field('name')
          ->set_error_message('min_length', 'must consist of atleast 6 characters')
          ->set_error_message('valid_string', 'must consist of only letters and spaces')
        ;
        $validator
          ->field('price')
          ->set_error_message('is_numeric', 'must be a valid number')
          ->set_error_message('match_pattern', 'must be non-neg. number')
        ;
        $validator
          ->field('instock')
          ->set_error_message('match_pattern', 'must be a non-neg. integer')
          ->set_error_message('numeric_min', 'must be atleast 1')
        ;
        return $validator;
    }

    public function action_addFlower() {

        // When initial and reentrant controllers are separate, no validation is
        // done on initial entry; so we just need a "placeholder" for validator.
        $validator = Validation::forge();

        $data = [
            'reentrantUrl' => "admin/addFlowerReentrant",
            'page_title' => 'Add Flower',
        ];

        $view = View::forge("admin/flower.tpl", $data);
        $view->set('validator', $validator, false); // pass validator
        return $view;
    }

    public function action_addFlowerReentrant() {

        $cancel = Input::post('cancel');
        if (!is_null($cancel)) {
            return Response::redirect("/");
        }

        $validator = $this->flowerValidator();

        $message = "";
        try {
            $validated = $validator->run(Input::post());
            if (!$validated) {
              throw new Exception();
            }
            $validData = $validator->validated();
            // All fields are valid.  A key point of using $validData instead of 
            // Input::post is that the validation trims the textfields.

            // check for duplicate name
            $flowerWithTitle = Model_Flower::find('first',[
               'where' => [ [ 'name', $validData['name'] ] ] 
            ]);
            if (!is_null($flowerWithTitle)) {
              throw new Exception('a flower with that name already exists');
            }
            // OK to go ahead and create flower.
            $flower = Model_Flower::forge();
            $flower->name = $validData['name'];
            $flower->price = number_format($validData['price'],2);
            $flower->description = $validData['description'];
            if($validData['imagefile'] == "") {
                $validData['imagefile'] = "NotAvailable.jpg";
            }
            $flower->imagefile = $validData['imagefile'];
            $flower->instock = $validData['instock'];
            $flower->save();

            return Response::redirect("/show/flower/$flower->id");
        }
        catch (Exception $ex) {
            $message = $ex->getMessage();  // unexpected error
        }

        // If we get here, we have an error of some kind, go back and fix it.
        $data = [
            'reentrantUrl' => "admin/addFlowerReentrant",
            'page_title' => 'Add Flower',

            'name' => Input::post('name'),
            'price' => Input::post('price'),
            'description' => Input::post('description'),
            'imagefile' => Input::post('imagefile'),
            'instock' => Input::post('instock'),

            'message' => $message,
        ];

        $view = View::forge("admin/flower.tpl", $data);
        $view->set('validator', $validator, false); // pass validator
        return $view;
    }
    
    public function action_modifyFlower($flower_id) {
        
        $flower = Model_Flower::find($flower_id);
        
        $validator = Validation::forge();
        $data = [
            'reentrantUrl' => "admin/modifyFlowerReentrant/$flower_id",
            'page_title' => 'Modify Flower',

            'name' => $flower->name,
            'price' => $flower->price,
            'description' => $flower->description,
            'imagefile' => $flower->imagefile,
            'instock' => $flower->instock,
            'flower_id' => $flower->id,
        ];
        $view = View::forge("admin/flower.tpl", $data);
        $view->set('validator', $validator, false); // pass validator
        return $view;
    }

    public function action_modifyFlowerReentrant($flower_id) {

        $cancel = Input::post('cancel');
        if (!is_null($cancel)) {
            return Response::redirect("/show/flower/$flower_id");
        }
        $flower = Model_Flower::find($flower_id);

        $validator = $this->flowerValidator();
        try {
            $validated = $validator->run(Input::post());
            if (!$validated) {
                throw new Exception();
            }
            $validData = $validator->validated();

            $flowerWithName = Model_Flower::find('first',[
                'where' => [ [ 'name', $validData['name'] ] ] 
            ]);
            if (!is_null($flowerWithName) and $flowerWithName->id != $flower->id) {
                // another flower with same name which is NOT the flower itself
                throw new Exception('another flower with that name already exists');
            }
            // OK to go ahead and modify
            $flower->name = $validData['name'];
            $flower->price = str_replace(",","", number_format($validData['price'], 2));
            $flower->description = $validData['description'];
            if($validData['imagefile'] == "") {
                $validData['imagefile'] = "NotAvailable.jpg";
            }
            $flower->imagefile = $validData['imagefile'];
            $flower->instock = $validData['instock'];
            $flower->save();

            return Response::redirect("/show/flower/$flower->id");
        }
        catch (Exception $ex) {
            $message = $ex->getMessage();
        }

        // If we get here, we have an error of some kind, go back and fix it.
        $data = [
            'reentrantUrl' => "admin/modifyFlowerReentrant/$flower_id",
            'page_title' => 'Modify Flower',

            'name' => Input::post('name'),
            'price' => Input::post('price'),
            'description' => Input::post('description'),
            'imagefile' => Input::post('imagefile'),
            'instock' => Input::post('instock'),
            'flower_id' => $flower_id,

            'message' => $message,
        ];

        $view = View::forge("admin/flower.tpl", $data);
        $view->set('validator', $validator, false); // pass validator
        return $view;
    }
    
    public function action_allOrders() {
        $message = "";
        $baskets = Model_Basket::find('all');
        $orders_data = [];
        
        if (!isset($baskets)) {
            $baskets = [];
            $message = "There are no orders";
        }
        
        foreach ($baskets as $basket_id => $member_id) {
            
            $basket = Model_Basket::find($basket_id);
            $member = Model_Member::find($basket->member_id);
            
            $orders_data[$basket_id] =
                    [
                        'id' => $basket->id,
                        'member_id' => $basket->member_id,
                        'member_name' => $member->name,
                        'made_on' => $basket->made_on
                    ];
        }
        //if there aren't any orders, print a message
        if ($orders_data == null) {
            $message = "There are no orders";
        }
        
        $data = [
            'page_title' => 'All Orders',
            'orderDetailsUrl' => "adminOrderDetails",
            
            'message' => $message,
            'orders_data' => $orders_data,
        ];

        return View::forge('member/orders.tpl', $data);
    }
    
    public function action_adminOrderDetails($basket_id) {
        $item_data = [];
        $total_price = 0;
        $basket = Model_Basket::find($basket_id);
        $currentMember = Model_Member::find($basket->member_id);
        
        $items = Model_Item::find('all', [
            'where' => array("basket_id" => $basket_id)
        ]);
        
        foreach ($items as $item_id => $flower_id) {
            $item = Model_item::find($item_id);
            $flower = Model_Flower::find($item->flower_id);
            //sum up the sub total of the current flower item
            $price = $item->price;
            $quantity = $item->quantity;
            $sub_total = (double) $price * $quantity;

            $item_data[$item_id] = 
                [
                    'id' => $item->id,
                    'basket_id' => $item->basket_id,
                    'flower_id' => $item->flower_id,
                    'name' => $flower->name,
                    'instock' => $flower->instock,
                    'price' => $item->price,
                    'quantity' => $item->quantity,
                    'sub_total' => $sub_total,
                ];
            //add sub total of current flower item to total cost of basket
            $total_price = $total_price + $sub_total;
        }
        $data = [
            'page_title' => "Order #$basket_id",
            'orderDetailsUrl' => "adminOrderDetails",
            
            'member_name' => $currentMember->name,
            'member_email' => $currentMember->email,
            'item_data' => $item_data,
            'total_price' => str_replace(",","", number_format($total_price, 2)),
        ];
        return View::forge('member/orderDetails.tpl', $data);
    }
    
    public function action_processOrder($basket_id) {
        //find the basket as well as it's items, to process
        $basket = Model_Basket::find($basket_id);
        $items = Model_Item::find('all', [
            'where' => array("basket_id" => $basket_id)
        ]);
        //check all of the items in the basket, to see if
        //quantity < instock
        $cannotProcess = false;
        foreach ($items as $item_id => $flower_id) {
            $item = Model_item::find($item_id);
            $flower = Model_Flower::find($item->flower_id);
            
            $quantity = $item->quantity;
            $instock = $flower->instock;
            if($quantity > $instock) {
                $cannotProcess = true;
                Session::set_flash("message","Cannot Process");
                return Response::redirect("admin/adminOrderDetails/$basket_id");
            }
        }
        $confirm = Input::post('confirm');
        if ($confirm) {
            //destroy all of the items in the basket
            foreach ($items as $item_id => $flower_id) {
                $item = Model_item::find($item_id);
                $flower = Model_Flower::find($item->flower_id);

                $quantity = $item->quantity;
                //subtract the quantity from the instock
                $flower->instock = ($flower->instock) - $quantity;
                $flower->save();
                $item->delete(); //then delete the item
            }
            //now destroy the basket itself
            $basket->delete();
            Session::set_flash("message","Order #$basket_id successfully processed");
            return Response::redirect("admin/allOrders");
        }
        //user must press submit button again to confirm removal
        Session::set_flash('confirm', 'yes');
        Session::set_flash('message', 'Are you sure? If so press remove again');
        return Response::redirect("admin/adminOrderDetails/$basket_id");
    }
}
<?php

class Controller_Show extends Controller_Base {

    public function before() {
        parent::before();
        $cart = Session::get('cart');
        if (is_null($cart)) {
          Session::set('cart', []);
        }
    }

    public function action_flower($flower_id) {
        $validator = Validation::forge();
        $flower = Model_Flower::find($flower_id);
        
        if (Session::get('cart') !== null) {
            foreach(Session::get('cart') as $flower_id => $quantity) {
                if ($flower_id == $flower->id) {
                    $this->quantity = $quantity;
                }
            }
        }
        if(!isset($this->quantity)) {
            $this->quantity = "";
        }
        $data = [
            'flower' => $flower,
            'quantity' => $this->quantity,
        ];
        $view = View::forge('home/showFlower.tpl', $data);
        $view->set('validator', $validator, false); // pass validator
        return $view;
    }
    
    private function quantityValidator() {
        
        $validator = Validation::forge();
        $validator->add('quantity', 'quantity')
          ->add_rule('trim')
          ->add_rule('required')
          ->add_rule('match_pattern', '/^\d+$/')
          ->add_rule('numeric_min', 1)
        ;
        // modify error messages
        $validator
          ->field('quantity')
          ->set_error_message('required', ':label cannot be empty')
          ->set_error_message('match_pattern', 'must be a non-neg. integer')
          ->set_error_message('numeric_min', 'must be atleast 1')
        ;
        return $validator;
    }

    public function action_cart() {
        
        $cart_data = [];
        $total_price = 0;
        $message = "";
        
        if(Session::get('cart') == null) {
            Session::set('cart', []);
            $message = "Cart is empty";
        }
        foreach(Session::get('cart') as $flower_id => $quantity) {
            $flower = Model_Flower::find($flower_id);
            //add to total price
            $price = $flower->price;
            $sub_total = (double) $price * $quantity;
            
            $cart_data[$flower_id] =
                ['id' => $flower->id, 'name' => $flower->name, 'price' => $flower->price, 'quantity' => $quantity, 'sub_total' => $sub_total];
            
            $total_price = $total_price + $sub_total;
        }
        $data = [
            'cart_data' => $cart_data,
            'page_title' => 'My Cart',
            'total_price' => str_replace(",","", number_format($total_price, 2)),
            'message' => $message,
        ];

        return View::forge('home/cart.tpl', $data);
    }
    
    public function action_addToCart($flower_id) {
        $flower = Model_Flower::find($flower_id);
        $validator = Validation::forge();

        $data = [
            'reentrantUrl' => "show/addToCartReentrant/$flower_id",
            'flower' => $flower,
            'flower_id' => $flower->id,
        ];

        $view = View::forge("home/showFlower.tpl", $data);
        $view->set('validator', $validator, false); // pass validator
        return $view;
    }
    
    public function action_addToCartReentrant($flower_id) {
        
        $flower = Model_Flower::find($flower_id);
        
        $clear = Input::post('clear');
        if (!is_null($clear)) {
            $cart = Session::get('cart');
            foreach(Session::get('cart') as $flower_id => $quantity) {
                if ($flower_id == $flower->id) {
                    unset($cart[$flower_id]);
                    Session::set('cart',$cart);
                    return Response::redirect("show/cart");
                }
            }
            return Response::redirect("show/flower/$flower->id");
        }
        
        $validator = $this->quantityValidator();
        try {
            $validated = $validator->run(Input::post());
            if (!$validated) {
              throw new Exception();
            }
            $validData = $validator->validated();
            
            $quantity = $validData['quantity'];
            //map quantity to a cart[flower_id] array
            $newCartEntry = Session::get('cart');
            if(is_null($newCartEntry)) {
                Session::set('cart',[]);
            }
            $newCartEntry[$flower_id] = $quantity;
            Session::set('cart', $newCartEntry);
            
            return Response::redirect("show/cart");
        }
        catch (Exception $ex) {
            $message = $ex->getMessage();
        }
        // If we get here, we have an error of some kind, go back and fix it.
        $data = [
            'reentrantUrl' => "show/addToCartReentrant/$flower_id",
            
            'quantity' => Input::post('quantity'),
            'flower' => $flower,
            'flower_id' => $flower_id,

            'message' => $message,
        ];

        $view = View::forge("home/showFlower.tpl", $data);
        $view->set('validator', $validator, false); // pass validator
        return $view;
    }
    
    public function action_placeOrder() {
        //get the current member
        $member = Session::get('member');
        //create a basket for the current member
        $basket = Model_Basket::forge();
        $basket->member_id = $member->id;
        $basket->made_on = date("Y-m-d@h:i:s", time());
        $basket->save();
        
        //now place cart items into basket
        foreach(Session::get('cart') as $flower_id => $quantity) {
            $flower = Model_Flower::find($flower_id);
            
            $item = Model_Item::forge();
            $item->flower_id = $flower_id;
            $item->basket_id = $basket->id;
            $item->quantity = $quantity;
            $item->price = $flower->price;
            $item->save();
            //now destroy the cart information
            $cart = Session::get('cart');
            unset($cart[$flower_id]);
            Session::set('cart',$cart);
        }
        if($member->is_admin) {
            return Response::redirect("admin/allOrders");
        }
        else {
            return Response::redirect("member/myOrders");
        }
    }
    
    public function action_setOrder() {
        
        $submit = Input::post('submit');
        $order = Input::post('order');
        
        if(isset($submit)) {
            Session::set('order', $order);
            $flowers = Model_Flower::find('all', [
                'order_by' => [ [ $order, 'ASC' ] ] 
            ]);
            $data = [
                'flowers' => $flowers,
                'order' => $order,
            ];
            return View::forge("home/index.tpl", $data);
        }
        
        $flowers = Model_flower::find('all');
        $data = [
            'flowers' => $flowers,
        ];
        return View::forge('home/index.tpl', $data);
    }
}
<?php

class Controller_Home extends Controller_Base {

    public function before() {
        parent::before();
    }

    public function action_index() {

        $order = Session::get('order');
        $default = "name";

        if($order == NULL || $order == "") {
            $order = $default;
            Session::set('order', $order);
            $flowers = Model_Flower::find('all', [
                'order_by' => [ [ $order, 'ASC' ] ] 
            ]);

            $data = [
                'order' => $order,
                'flowers' => $flowers,
            ];
            return View::forge('home/index.tpl', $data);
        }
        $flowers = Model_Flower::find('all', [
            'order_by' => [ [ $order, 'ASC' ] ] 
        ]);
        $data = [
            'order' => $order,
            'flowers' => $flowers,
        ];
        return View::forge('home/index.tpl', $data);
    }
    
    public function accountValidator() {
        
        // build validators directly right here
        $validator = Validation::forge();
        $validator->add('name', 'name')
            ->add_rule('trim')
            ->add_rule('required')
            ->add_rule('min_length', 3)
            ->add_rule('match_pattern','[^[a-zA-Z][a-zA-Z\d]*$]');
        ;
        $validator->add('email', 'email')
            ->add_rule('trim')
            ->add_rule('required')
            ->add_rule('valid_email')
        ;
        $validator->add('password', 'password')
            ->add_rule('trim')
            ->add_rule('required')
            ->add_rule('min_length', 3)
        ;
        $validator->add('confirm', 'confirm')
            ->add_rule('trim')
            ->add_rule('required')
            ->add_rule('min_length', 3)
            ->add_rule('match_value', Input::post('password'), true)
        ;
        
        // modify error messages
        $validator
          ->set_message('required', ':label cannot be empty')
          ->set_message('min_length', 'at least :param:1 char(s)')
        ;
        $validator
          ->field('name')
          ->set_error_message('match_pattern', 'name must consist of only letters and digits, starting with a letter')
        ;
        $validator
          ->field('confirm')
          ->set_error_message('match_value', 'confirm must match password')
        ;
        return $validator;
    }
    
    public function action_createAccount() {
        
        $validator = Validation::forge();
        $data = [
            'reentrantUrl' => "home/createAccountReentrant",
            'page_title' => 'Create Account',
        ];

        $view = View::forge("home/createAccount.tpl", $data);
        $view->set('validator', $validator, false); // pass validator
        return $view;
    }
    
    public function action_createAccountReentrant() {
    
        $cancel = Input::post('cancel');
        if (!is_null($cancel)) {
            return Response::redirect("/");
        }

        $validator = $this->accountValidator();

        $message = "";
        try {
            $validated = $validator->run(Input::post());
            if (!$validated) {
                throw new Exception();
            }
            $validData = $validator->validated();

            // check for duplicate username
            $memberWithName = Model_Member::find('first',[
               'where' => [ [ "name", $validData['name'] ] ] 
            ]);
            if (!is_null($memberWithName)) {
                throw new Exception('a member with that username already exists');
            }

            // OK to go ahead and create book.
            $member = Model_Member::forge();
            $member->name = $validData['name'];
            $member->email = $validData['email'];
            //encode the password into the hash
            $password = $validData['password'];
            $member->password = hash('sha256', $password);
            $member->save();
            
            return Response::redirect("/authenticate/login");
        }
        catch (Exception $ex) {
            $message = $ex->getMessage();  // unexpected error
        }

        // If we get here, we have an error of some kind, go back and fix it.
        
        $data = [
            'reentrantUrl' => "home/createAccountReentrant",
            'page_title' => 'Create Account',
            
            'name' => Input::post('name'),
            'email' => Input::post('email'),
            'password' => "",
            'confirm' => "",

            'message' => $message,
        ];

        $view = View::forge("home/createAccount.tpl", $data);
        $view->set('validator', $validator, false); // pass validator
        return $view;
    }
}

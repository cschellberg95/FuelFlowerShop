<?php

class Controller_Member extends Controller_Base {
    
    public function before() {
        parent::before();
        if (is_null($this->sessionMember)) {
          return Response::redirect('/authenticate/login');
        }
    }
    
    public function action_myOrders() {
        $currentMember = Session::get("member");
        $message = "";
        $baskets = Model_Basket::find('all');
        $orders_data = [];
        
        foreach ($baskets as $basket_id => $member_id) {
            
            $basket = Model_Basket::find($basket_id);
            $member = Model_Member::find('first', [
                'where'=> array( "id" => $basket->member_id )
            ]);        
            if($member == $currentMember->name) {
                $orders_data[$basket_id] =
                    [
                        'id' => $basket->id,
                        'member_id' => $basket->member_id,
                        'member_name' => $member->name,
                        'made_on' => $basket->made_on
                    ];
            }
        }
        //if there aren't any orders, print a message
        if ($orders_data == null) {
            $message = "There are no orders";
        }
        
        $data = [
            'page_title' => 'My Orders',
            'orderDetailsUrl' => "memberOrderDetails",
            
            'message' => $message,
            'orders_data' => $orders_data,
        ];

        return View::forge('member/orders.tpl', $data);
    }
    
    public function action_memberOrderDetails($basket_id) {
        //$currentMember = Session::get("member");
        //var_dump($currentMember->id);
        //exit();
        $item_data = [];
        $total_price = 0;
        
        $items = Model_Item::find('all', [
            'where' => array("basket_id" => $basket_id)
        ]);
        foreach ($items as $item_id => $flower_id) {
            $item = Model_item::find($item_id);
            $flower = Model_Flower::find($item->flower_id);
            //sum up the sub total of the current flower item
            $price = $item->price;
            $quantity = $item->quantity;
            $sub_total = (double) $price * $quantity;

            $item_data[$item_id] = 
                [
                    'id' => $item->id,
                    'basket_id' => $item->basket_id,
                    'flower_id' => $item->flower_id,
                    'name' => $flower->name,
                    'instock' => $flower->instock,
                    'price' => $item->price,
                    'quantity' => $item->quantity,
                    'sub_total' => $sub_total,
                ];
            //add sub total of current flower item to total cost of basket
            $total_price = $total_price + $sub_total;
        }
        $data = [
            'page_title' => "Order #$basket_id",
            'orderDetailsUrl' => "memberOrderDetails",
            
            'item_data' => $item_data,
            'total_price' => str_replace(",","", number_format($total_price, 2)),
        ];
        return View::forge('member/orderDetails.tpl', $data);
    }
}